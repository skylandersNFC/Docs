ACS CCID PC/SC Driver for Windows CE 6.0
Advanced Card Systems Ltd.



Contents
----------------

   1. Release Notes
   2. Installation
   3. Sample Program
   4. History
   5. File Contents
   6. Limitations
   7. Support



1. Release Notes
----------------

Version: 2.0.1.0
Release Date: 23/11/2015

Supported Readers
ACR38U-CCID
ACR100-CCID
ACR100 ICC Reader
ACR101 ICC Reader
ACR102 ICC Reader
ACR122U
ACR122U-SAM
ACR123U
ACR123U Bootloader
ACR1251U-A1
ACR1251U-A2
ACR1251U-C (SAM)
ACR1251U-C
ACR1251UK
ACR1251U-C3
ACR1281 Bootloader
ACR1252U-A1
ACR1252U-A2
ACR1252U BL

Supported CPU Architectures 
x86
ARMV4I

To use the driver, please add Smart Card support to your catalog in Platform Builder.



2. Installation
---------------

You can install the driver either using Platform Builder or ActiveSync.

Platform Builder
----------------

1. Select Settings in Platform menu. You will see Platform Settings dialog box.

2. Click on Custom Build Actions tab. Select Pre-Make Image in build step.

3. Click on New... button to add the action.

4. Assume you have copied the driver file in "%PBWORKSPACEROOT%\drivers\acsccid\x86\acsccid.dll". Enter "copy %PBWORKSPACEROOT%\drivers\acsccid\x86\acsccid.dll %_FLATRELEASEDIR%" in the Custom Build Action dialog box. Click on OK button to finish.

5. Click on OK button in Platform Settings dialog box to apply the settings.

6. Edit the MODULES section of Project.bib to add an entry to the driver file.

MODULES
; Name            Path                              Memory  Type
; --------------  --------------------------------  ------  ----
  acsccid.dll     $(_FLATRELEASEDIR)\acsccid.dll    NK      SHK

7. Edit Project.reg to add an entry to the driver registry file. Assume you have copied the driver registry file in "%PBWORKSPACEROOT%\drivers\acsccid\acsccid.reg".

#include "$(PBWORKSPACEROOT)\drivers\acsccid\acsccid.reg"



ActiveSync
----------

1. Use ActiveSync to connect and transfer "acsccid.cab" file to your device.

2. In your device, double-click the cab file to start the driver installation.



3. Sample Program
-----------------

To use the APDU test program, please add Console support to your catalog in Platform Builder.

To run the APDU test program:

1. Plug in ACR122U reader to one of the available USB ports.

2. Make sure that you have copied testapdu.exe and scripts folder to Windows CE.

3. Select Command Prompt from Programs menu in Windows CE.

4. In this example, Mifare 1k card will be used. Place the Mifare 1k card and enter "testapdu \scripts\ACR122U\Mifare1k.txt" in Command Prompt. You will see the following sample output.

APDU Test for Windows CE
Copyright (C) 2015 Advanced Card Systems Ltd. All Rights Reserved.
Establishing the context...
Listing the readers...
Reader 0: ACS ACR122U 0
Select reader: 0
Connecting to ACS ACR122U 0...
Active protocol T1
Getting the card status...
ATR:
3B 8F 80 01 80 4F 0C A0 00 00 03 06 03 00 01 00
00 00 00 6A
Beginning the transaction...
Opening \scripts\acr122u\mifare1k.txt...
Command:
FF 82 00 00 06 FF FF FF FF FF FF
Response:
90 00
Expected:
90 00
Compare OK
Command:
FF 86 00 00 05 01 00 00 60 00
Response:
90 00
Expected:
90 00
Compare OK
Command:
FF B0 00 01 10
Response:
00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F
90 00
Expected:
XX XX XX XX XX XX XX XX XX XX XX XX XX XX XX XX
90 00
Compare OK
Command:
FF D6 00 01 10 00 01 02 03 04 05 06 07 08 09 0A
0B 0C 0D 0E 0F
Response:
90 00
Expected:
90 00
Compare OK
Command:
FF B0 00 01 10
Response:
00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F
90 00
Expected:
XX XX XX XX XX XX XX XX XX XX XX XX XX XX XX XX
90 00
Compare OK
Command:
FF 86 00 00 05 01 00 05 60 00
Response:
90 00
Expected:
90 00
Compare OK
Command:
FF D7 00 05 05 00 00 00 00 01
Response:
90 00
Expected:
90 00
Compare OK
Command:
FF B1 00 05 04
Response:
00 00 00 01 90 00
Expected:
XX XX XX XX 90 00
Compare OK
Command:
FF D7 00 05 02 03 06
Response:
90 00
Expected:
90 00
Compare OK
Command:
FF B1 00 06 04
Response:
00 00 00 01 90 00
Expected:
XX XX XX XX 90 00
Compare OK
Command:
FF D7 00 05 05 01 00 00 00 05
Response:
90 00
Expected:
90 00
Compare OK
Command:
FF B1 00 05 04
Response:
00 00 00 06 90 00
Expected:
XX XX XX XX 90 00
Compare OK
Ending the transaction...

5. The test program will transmit APDU one by one and compare the actual response with expected response. After the test is finished, it will prompt you to insert/remove the card within 10 seconds to test for card status change.

Please insert/remove the card within 10 seconds...
Status Change: 0x00000000 -> 0x00000022
ATR:
3B 8F 80 01 80 4F 0C A0 00 00 03 06 03 00 01 00
00 00 00 6A
Status Change: 0x00000022 -> 0x00000012
Status Change: 0x00000012 -> 0x00000022
ATR:
3B 8F 80 01 80 4F 0C A0 00 00 03 06 03 00 01 00
00 00 00 6A
Status Change: 0x00000022 -> 0x00000012
Status Change: 0x00000012 -> 0x00000022
ATR:
3B 8F 80 01 80 4F 0C A0 00 00 03 06 03 00 01 00
00 00 00 6A
Status Change: 0x00000022 -> 0x00000012
Status Change: 0x00000012 -> 0x00000022
ATR:
3B 8F 80 01 80 4F 0C A0 00 00 03 06 03 00 01 00
00 00 00 6A
Status Change: 0x00000022 -> 0x00000012
Status Change: 0x00000012 -> 0x00000022
ATR:
3B 8F 80 01 80 4F 0C A0 00 00 03 06 03 00 01 00
00 00 00 6A
Error: SCardGetStatusChange failed with error 0x8010000a
Continue (y/n)? n
Releasing the context...



4. History
----------

v1.0.0.1 (26/11/2008)
1. New Release

v1.0.1.1 (4/12/2008)
1. Set the reader name according to USB string descriptors in reader.
2. Follow the reader name convention from Windows.

v1.0.1.2 (15/12/2008)
1. Add VERSIONINFO resource.

v1.0.2.1 (30/1/2009)
1. Add ACR38U-CCID support.
2. Fix response checking bug in APDU test program.

v1.0.2.1 (28/1/2010)
1. Enable polling mode automatically for ACR122U v2.06.
2. Fix PPS problem.

v1.0.3.1 (7/7/2011)
1. Add the following readers support:
   ACR100 ICC Reader
   ACR101 ICC Reader
   ACR102 ICC Reader
   ACR1222L 3S CL Reader (PID: 0x2225)

v1.0.4.1 (26/10/2011)
1. Add ACR1251 PICC Reader support.

v2.0.0.0 (27/10/2014)
1. Added support to the following readers:
	ACR123U
	ACR123U Bootloader
	ACR1251U-A1
	ACR1251U-A2
	ACR1251U-C (SAM)
	ACR1251U-C
	ACR1251UK
	ACR1251U-C3
	ACR1281 Bootloader
	ACR1252U-A1
	ACR1252U-A2
	ACR1252U BL

v2.0.0.0 (09/12/2014)
1. Fixed card detection for ACR1251U-C3 and ACR123
2. Added mandatory parameter setting if card state is specific 
3. Added separate Mifare test script for ACR123

v2.0.0.0 (10/12/2014)
1. Fixed SAM slot card detection for ACR1251U-A1

v2.0.1.0 (16/10/2015)
1. Implemented use of single DLL file to support multiple readers
2. Added Unit Number in Reader Name

v2.0.1.0 (23/11/2015)
1. Fixed ICC slot card detection for ACR1251UK



|   ReadMe.txt
|
+---bin
|   +---ARMV4I
|   |       testapdu.exe
|   |
|   \---x86
|           testapdu.exe
|
+---drivers
|   \---acsccid
|       |   acsccid.reg
|       |
|       +---ARMV4I
|       |       acsccid.inf
|   	|	acsccid.cab
|       |       acsccid.dll
|       |
|       \---x86
|               acsccid.inf
|   		acsccid.cab
|               acsccid.dll
|
+---scripts
|   +---pcsc
|   |       Mifare1K.txt
|   |       Mifare1K_ACR123U.txt
|   |       ACOS3.txt
|   |       Basic.txt
|   |
|   +---proprietary
|   	\---ACR122U
|          	Topaz.txt
|          	UltraLight.txt
|   	    	ACOS3.txt         	
|
\---src
    \---testapdu
            makefile
            postlink.bat
            prelink.bat
            ProjSysgen.bat
            ReadMe.txt
            sources
            StdAfx.cpp
            StdAfx.h
            testapdu.bib
            testapdu.cpp
            testapdu.dat
            testapdu.db
            testapdu.pbpxml
            testapdu.reg



6. Limitations
--------------



7. Support
----------

In case of problem, please contact ACS through:

Web Site: http://www.acs.com.hk/
E-mail: info@acs.com.hk
Tel: +852 2796 7873
Fax: +852 2796 1286



-----------------------------------------------------------------


Copyright
Copyright by Advanced Card Systems Ltd. (ACS) No part of this reference manual may be reproduced or transmitted in any from without the expressed, written permission of ACS.

Notice
Due to rapid change in technology, some of specifications mentioned in this publication are subject to change without notice. Information furnished is believed to be accurate and reliable. ACS assumes no responsibility for any errors or omissions, which may appear in this document.
